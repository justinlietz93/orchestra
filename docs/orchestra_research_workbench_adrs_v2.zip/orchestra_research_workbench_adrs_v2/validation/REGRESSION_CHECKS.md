# Regression Checks

A release fails when any check fails.

## Text checks

No controlling document may contain these implications:

```text
Research Workbench → Operator
completed run enters the pipeline
attach to Operator handoff
workbench output must pass Guardian and Auditor before use
attachment means provided
search indexing means agent awareness
```

## Behavioral checks

1. Completing a run leaves workflow position unchanged.
2. Attaching a summary creates no ExposureEvent.
3. Attaching a summary leaves all role states `not_provided`.
4. Default Operator package excludes `user-research/`.
5. Default Guardian package excludes `user-research/`.
6. Default Auditor package excludes `user-research/`.
7. Explicit selection creates one role-specific handoff manifest.
8. A summary-only handoff does not include full-run artifacts.
9. Search results display origin and exposure badges.
10. Publication export reports unreviewed user research rather than hiding or upgrading it.

## Schema checks

All JSON Schemas must validate under Draft 2020-12.

The example attachment and handoff records must validate.
