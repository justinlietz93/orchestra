# Package Validation Report

**Overall:** PASS

- PASS — schema:agent_handoff_manifest.schema.json: valid Draft 2020-12
- PASS — schema:claim_record.schema.json: valid Draft 2020-12
- PASS — schema:evidence_item.schema.json: valid Draft 2020-12
- PASS — schema:exposure_event.schema.json: valid Draft 2020-12
- PASS — schema:publication_bundle.schema.json: valid Draft 2020-12
- PASS — schema:research_run.schema.json: valid Draft 2020-12
- PASS — schema:workbench_attachment.schema.json: valid Draft 2020-12
- PASS — example:workbench_attachment: valid
- PASS — example:agent_handoff_manifest: valid
- PASS — regression:direct workbench to operator edge: absent
- PASS — regression:attach to current Operator handoff: absent
- PASS — regression:must pass Guardian and Auditor before use: absent
- PASS — required:Attachment does not imply: present
- PASS — required:excluded from agent handoff packages by default: present
- PASS — required:explicit handoff manifest: present
- PASS — required:user_curated: present
- PASS — required:pipeline_authority: present
