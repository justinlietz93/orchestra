# Integration Overview

## Target architecture

```mermaid
flowchart LR
    U[User] --> O[Orchestra Desktop]

    subgraph Pipeline["Orchestra Pipeline"]
      WF[Workflow State\nPhase / Branch / Version]
      OP[Operator]
      GU[Guardian]
      AU[Auditor]
      OP --> GU --> AU
      AU --> WF
    end

    subgraph Record["Shared Project Record"]
      PG[Project Graph Search]
      AR[Artifact Registry]
      EV[Exposure Ledger]
      TL[Version Timeline]
    end

    subgraph Workbench["User Research Workbench"]
      RC[Campaigns and Runs]
      IC[Internal Project Search]
      EC[External Research]
      CP[Critique and Synthesis]
      PB[Publication Builder]
      RC --> IC
      RC --> EC
      RC --> CP
      IC --> PB
      EC --> PB
      CP --> PB
    end

    O --> Pipeline
    O --> Record
    O --> Workbench

    Workbench -->|attach user summary only| AR
    AR --> PG
    AR --> TL

    U -->|explicit artifact selection| HM[Agent Handoff Manifest]
    HM --> EV
    HM --> OP
    HM --> GU
    HM --> AU
```

## Critical boundary

There is no automatic edge from the Research Workbench to the Operator, Guardian, or Auditor.

A workbench result can become visible in project history without becoming agent context.

## Attachment behavior

A completed run may create:

```text
<p-b-v>/
    user-research/
        <attachment-id>/
            summary.md
            provenance.json
            artifact-links.json
```

The full immutable run may remain in the workbench content store. The attached record contains exact hashes and links.

## Delivery behavior

The user may explicitly select one or more artifacts and choose:

```text
Provide to Operator
Provide to Guardian
Provide to Auditor
```

That action creates an immutable handoff manifest. The application must show the exact artifacts and hashes before recording delivery.

## Non-implications

```text
Attached to p-b-v
    does not mean provided.

Provided to Operator
    does not mean provided to Guardian or Auditor.

Summary provided
    does not mean full run or sources provided.

Agent cited artifact
    does not mean Auditor accepted its claims.
```
