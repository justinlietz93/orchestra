# Cogito Component Disposition

## Reuse behind workbench boundaries

| Cogito capability | Disposition | Orchestra destination |
|---|---|---|
| Query planning | Adapt | User Research Workbench planner |
| ArXiv search | Adapt | External connector |
| PubMed search | Adapt | External connector |
| Semantic Scholar search | Adapt | External connector |
| CrossRef metadata | Adapt | External connector |
| Web search | Adapt with policy controls | External connector |
| Result deduplication | Reuse after tests | Source normalization |
| Vector search | Adapt | Workbench internal corpus lane |
| Directory ingestion | Adapt | Explicit user-selected ingestion |
| Critique Council | Rebuild as user-triggered templates | Workbench critique runs |
| Synthesis | Rebuild with claim/evidence schemas | Workbench synthesis |
| BibTeX generation | Reuse after tests | Publication builder |
| LaTeX/PDF generation | Reuse after tests | Publication builder |

## Reject as controlling architecture

- fixed Cogito project directories;
- a fixed universal research pipeline;
- direct automatic synthesis into project canon;
- implicit sending of research results to agents;
- prose-only council outputs;
- mutable latest-result files;
- hidden provider-specific state;
- automatic workflow advancement.

## Boundary adapter

Cogito-derived services return immutable workbench artifacts.

They do not call Operator, Guardian, Auditor, or workflow-position APIs.
