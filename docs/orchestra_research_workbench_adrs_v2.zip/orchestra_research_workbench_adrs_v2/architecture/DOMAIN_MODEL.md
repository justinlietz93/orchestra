# Research Workbench Domain Model

## Primary entities

### Project

The existing Orchestra project.

### WorkflowPosition

The current phase, branch, version, and expected pipeline role.

The Research Workbench may reference this position. It may not mutate it.

### ResearchCampaign

A user-created research objective.

A campaign may be linked to a project and may span several immutable runs.

### ResearchRun

One immutable execution of a research plan.

The run belongs to the user workbench. It is not an Operator interaction.

### ResearchSummary

A user-facing summary generated from one or more ResearchRuns.

A summary records its generator, source runs, exact hash, and limitations.

### WorkbenchAttachment

A chronological link between a ResearchSummary or other workbench artifact and a selected p-b-v record.

Attachment records:

- artifact ID and hash;
- selected interaction;
- attachment time;
- user attribution;
- statement that attachment does not imply agent delivery.

### ExposureEvent

An immutable event describing actual artifact exposure.

Examples:

- `provided_to_operator`
- `provided_to_guardian`
- `provided_to_auditor`
- `acknowledged_by_operator`
- `cited_by_auditor`
- `relied_on_by_operator`

No event is inferred merely from another event.

### AgentHandoffManifest

The exact list of artifacts delivered to one role for one interaction.

A handoff manifest is role-specific and hash-specific.

### SourceRecord

Canonical metadata for an internal or external source.

### SourceSnapshot

The exact source version or content used by a run.

### EvidenceItem

A bounded passage, figure, table, computation, or observation extracted from a snapshot.

### ClaimRecord

A workbench proposition linked to evidence.

A ClaimRecord is not a project-canon claim unless a separate project process establishes that status.

### PublicationBundle

A manuscript bundle with claim, source, workbench, exposure, pipeline, and decision provenance.

## Relationships

```mermaid
erDiagram
    PROJECT ||--o{ RESEARCH_CAMPAIGN : contains
    RESEARCH_CAMPAIGN ||--o{ RESEARCH_RUN : executes
    RESEARCH_RUN ||--o{ RESEARCH_SUMMARY : produces
    RESEARCH_RUN ||--o{ SOURCE_SNAPSHOT : uses
    SOURCE_SNAPSHOT ||--o{ EVIDENCE_ITEM : yields
    CLAIM_RECORD }o--o{ EVIDENCE_ITEM : linked_to
    RESEARCH_SUMMARY }o--o{ CLAIM_RECORD : summarizes

    WORKFLOW_POSITION ||--o{ WORKBENCH_ATTACHMENT : records
    RESEARCH_SUMMARY ||--o{ WORKBENCH_ATTACHMENT : attached_as

    AGENT_HANDOFF_MANIFEST ||--o{ EXPOSURE_EVENT : records
    RESEARCH_SUMMARY }o--o{ AGENT_HANDOFF_MANIFEST : may_include
    SOURCE_SNAPSHOT }o--o{ AGENT_HANDOFF_MANIFEST : may_include

    PUBLICATION_BUNDLE }o--o{ CLAIM_RECORD : includes
    PUBLICATION_BUNDLE }o--o{ EXPOSURE_EVENT : reports
```

## Workbench claim states

- `candidate`
- `supported`
- `contested`
- `refuted`
- `unresolved`
- `superseded`
- `selected_for_manuscript`

These states describe user research. They do not claim Guardian passage, Auditor acceptance, or project canon.

## Independent provenance dimensions

Every artifact may have separate values for:

- origin;
- attachment;
- exposure;
- acknowledgment;
- use;
- audit;
- adoption;
- publication inclusion.

Do not compress these dimensions into one status field.
