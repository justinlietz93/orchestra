# Exposure and Handoff Model

## Why a separate model is required

A file can exist in the project without being known to any agent.

A summary can be attached to the current version without being included in an agent prompt.

An agent can receive a summary without receiving the full run, sources, or attachments.

The data model must preserve those distinctions.

## Exposure chain

```text
CREATED
ATTACHED
PROVIDED
ACKNOWLEDGED
RELIED_ON
AUDITED
ADOPTED
PUBLISHED
```

This is not a mandatory linear state machine.

Each item is an event or relation. The application must not infer missing steps.

## Exact handoff

Each agent handoff contains:

- project ID;
- phase, branch, and version;
- target role;
- target interaction;
- handoff time;
- user identity;
- exact artifact IDs;
- exact artifact hashes;
- whether each artifact is a summary, full run, source snapshot, or other file;
- optional user note.

## Manual delivery

When the user sends an artifact outside Orchestra, the application may record a manual-delivery event.

The event must state that the delivery was user-recorded and not application-verified.

## Acknowledgment and use

Acknowledgment or use should be recorded only when:

- the agent explicitly names or cites the artifact;
- the agent response includes its artifact ID or hash;
- the user manually records an observed use with a note.

## Packaging rule

Generated pipeline packages exclude all `user-research/` content by default.

An artifact enters a handoff package only through an explicit selection that writes it to the handoff manifest.
