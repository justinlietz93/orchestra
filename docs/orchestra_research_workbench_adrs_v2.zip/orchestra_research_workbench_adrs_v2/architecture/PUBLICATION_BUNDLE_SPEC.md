# Publication Bundle Specification

## Bundle shape

```text
publication_<paper-id>_<timestamp>/
    README.md
    MANIFEST.json
    MANIFEST.sha256

    paper/
        manuscript.md
        manuscript.tex
        manuscript.pdf
        figures/
        tables/
        bibliography.bib
        citation-map.json

    provenance/
        claim-ledger.json
        claim-ledger.md
        claim-to-source.csv
        claim-origin-map.csv
        user-research-runs/
        source-snapshots/
        accepted-experiment-packages/
        guardian-ratifications/
        auditor-decisions/
        agent-intake-manifests/
        exposure-ledger.jsonl
        version-timeline.json
        negative-results.md
        superseded-claims.md
        reproducibility.md
        artifact-hashes.json

    review/
        unresolved-claims.md
        citation-gaps.md
        conflicts.md
        manuscript-audit.md
        unreviewed-user-research.md
```

## Inclusion rule

The user controls manuscript inclusion.

A claim may enter the manuscript when:

1. it has an exact claim record;
2. its cited sources resolve to exact source snapshots or internal artifacts;
3. its evidence relation is explicit;
4. its uncertainty and review status are recorded;
5. the bundle does not imply agent review that did not occur.

Guardian and Auditor records are included when they exist. They are not mandatory for every user-researched claim.

## Export policies

The publication builder may offer:

- `user_curated`
- `auditor_accepted_only`
- `pipeline_and_user_research`
- `external_literature_only`

The default must not silently discard user research or silently present it as audited.

## Claim-origin map

Each manuscript claim records:

- user workbench origin, pipeline origin, or both;
- exact supporting artifacts;
- whether it was provided to each agent;
- whether an agent cited or relied on it;
- Guardian status when applicable;
- Auditor status when applicable;
- manuscript location.

## Reproducibility

The bundle records:

- software version;
- schema versions;
- source retrieval metadata;
- query plan;
- prompt and model hashes when used;
- user selections;
- exposure events;
- experiment commands;
- environment lockfiles;
- deterministic and nondeterministic steps.
