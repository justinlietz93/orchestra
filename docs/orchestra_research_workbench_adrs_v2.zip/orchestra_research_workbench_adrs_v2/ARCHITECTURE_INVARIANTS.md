# Architecture Invariants

These invariants are regression barriers.

## INV-001 — User-only sidecar

The Research Workbench is operated by the user. It is not an agent in the Orchestra pipeline.

## INV-002 — No automatic agent exposure

Creating, completing, attaching, indexing, searching, exporting, or opening a workbench artifact does not provide it to any agent.

## INV-003 — Exact intake

An agent is considered to have received an artifact only when the artifact hash appears in an explicit handoff manifest for that role and interaction, or the user records an equivalent manual-delivery event.

## INV-004 — Attachment is chronology

Attaching a summary to a p-b-v record means only that the user performed or recorded that research at that point in project history.

## INV-005 — No inferred use

Provided does not imply acknowledged. Acknowledged does not imply relied on. Relied on does not imply accepted.

## INV-006 — Pipeline isolation

Workbench events cannot advance phase, branch, version, or role position.

## INV-007 — Default exclusion

`user-research/` is excluded from generated Operator, Guardian, and Auditor handoff packages unless the user explicitly selects an artifact.

## INV-008 — Immutable exposure history

Delivery and exposure events are append-only and tied to exact artifact hashes.

## INV-009 — Search is non-authoritative

Project search may find workbench artifacts, but search results must display origin and exposure state. Indexing does not change authority.

## INV-010 — Publication independence

The user may use workbench research in a paper without first entering it into the agent pipeline. The publication bundle must state the actual review and exposure history.

## INV-011 — Optional pipeline use

The user may later provide any selected workbench artifact to the Operator, Guardian, or Auditor. That action is explicit, role-specific, interaction-specific, and hash-specific.

## INV-012 — No hidden context claim

A project record must never imply that an agent had access to a source, full run, or supporting archive when only a summary was provided.
