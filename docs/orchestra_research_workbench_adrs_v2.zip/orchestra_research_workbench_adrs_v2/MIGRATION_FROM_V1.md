# Migration from the v1 ADR Package

## Verdict on v1

**REVISE AND SUPERSEDE**

The first package correctly kept Orchestra as the system of record and prevented workbench-driven version advancement. It nevertheless made the Research Workbench too close to the agent pipeline.

The following v1 statements are withdrawn:

```text
Research Workbench → Operator → Guardian → Auditor
Completed runs can be inserted directly into a pipeline handoff.
Research outputs enter canon only through existing gates.
Phase 5: Workflow handoff.
```

## Replacement model

```text
User Research Workbench
    creates immutable user research runs
    may attach a summary to a selected p-b-v record
    does not provide artifacts to agents automatically

Explicit user delivery
    selects exact artifacts and hashes
    creates an agent handoff manifest
    records a provided-to-agent event

Orchestra pipeline
    remains independently sequenced
    receives only artifacts listed in its exact intake manifest
```

## File-level changes

- ADR-0001 now defines the workbench as a user-only sidecar.
- ADR-0007 now defines attachment without delivery or promotion.
- ADR-0008 keeps councils inside the user workbench.
- ADR-0011 makes the workbench a separate application branch.
- ADR-0013 adds the exposure ledger and exact handoff manifests.
- ADR-0014 separates paper inclusion from agent review.
- The integration diagram no longer connects the workbench directly to the Operator.
- The publication bundle no longer requires Guardian or Auditor review for every included claim.
- The roadmap no longer contains a workflow-handoff phase.
