# ADR-0005: Use provider-neutral research connectors

**Status:** Proposed  
**Date:** 2026-07-13

## Decision

Define provider-neutral connector interfaces for ArXiv, CrossRef, Semantic Scholar, PubMed, selected web search, and internal project search.

Connectors return normalized records plus namespaced raw metadata.

## Acceptance criteria

- Provider replacement does not change the domain model.
- Credentials remain outside project artifacts.
- Connector output stays inside the user workbench until explicitly attached or exported.
