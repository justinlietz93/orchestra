# ADR-0008: Keep critique and synthesis councils inside the user workbench

**Status:** Proposed  
**Date:** 2026-07-13  
**Supersedes:** ADR-0008 from v1

## Decision

Cogito-style councils are user-triggered ResearchRun tasks.

They emit structured findings, evidence links, disagreements, and uncertainty.

They are not Orchestra pipeline roles.

## Acceptance criteria

- Council results are labeled user research.
- Dissent remains preserved.
- Council completion does not create Operator, Guardian, or Auditor work.
- The user must explicitly provide any council artifact to an agent.
