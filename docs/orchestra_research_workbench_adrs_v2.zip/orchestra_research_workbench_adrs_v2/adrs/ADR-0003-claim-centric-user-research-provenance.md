# ADR-0003: Add claim-centric provenance without granting authority

**Status:** Proposed  
**Date:** 2026-07-13

## Decision

Represent workbench claims as graph nodes linked to source snapshots, evidence items, research runs, contradictions, and manuscript locations.

A workbench ClaimRecord describes user research. It does not become project canon merely by existing, being attached, or appearing in search.

## Acceptance criteria

- Search results display `USER RESEARCH`.
- Claim origin and review status are independent fields.
- No claim state is named `canonical`.
