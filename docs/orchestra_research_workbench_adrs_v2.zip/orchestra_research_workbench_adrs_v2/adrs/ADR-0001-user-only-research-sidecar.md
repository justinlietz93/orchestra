# ADR-0001: Keep the Research Workbench as a user-only sidecar

**Status:** Proposed  
**Date:** 2026-07-13  
**Supersedes:** ADR-0001 from v1

## Context

Orchestra already has a controlled Operator → Guardian → Auditor pipeline. The user wants a separate research environment for internal recovery, external literature work, and manuscript preparation.

## Decision

Implement the Research Workbench as a user-only sidecar inside the Orchestra desktop application.

It shares the project artifact registry and graph index. It does not participate in pipeline sequencing.

## Consequences

- Workbench research can be chronologically recorded without becoming agent context.
- The existing pipeline remains unchanged.
- Integration code must not expose workflow mutation methods to the workbench.

## Acceptance criteria

- Removing the workbench leaves pipeline behavior unchanged.
- No workbench service can advance phase, branch, version, or role.
- No workbench completion event targets an agent automatically.
