# ADR-0011: Present the Research Workbench as a separate GUI branch

**Status:** Proposed  
**Date:** 2026-07-13  
**Supersedes:** ADR-0011 from v1

## Decision

Add a distinct Research Workbench branch or workspace in the Orchestra desktop application.

Keep its navigation and state visually separate from the Operator → Guardian → Auditor workflow.

## Required actions

- Start research from graph node.
- Create campaign.
- Run internal or external research.
- Attach summary to selected p-b-v.
- Select exact artifacts for agent delivery.
- View exposure history.
- Build publication bundle.

## Acceptance criteria

- Research completion never changes the workflow-position panel.
- The GUI shows `Not provided` by default for every role.
- Delivery controls show exact selected artifact hashes.
