# ADR-0014: Preserve actual review history in publication bundles

**Status:** Proposed  
**Date:** 2026-07-13

## Decision

The user may include workbench research in a manuscript without first routing it through the Orchestra agents.

The publication bundle must state the actual history:

- origin;
- supporting sources;
- attachment;
- agent exposure;
- agent use;
- Guardian review;
- Auditor review;
- adoption;
- manuscript location.

## Consequences

- User-directed scholarship remains first-class.
- Optional agent review remains visible when it occurred.
- The bundle cannot imply review that did not happen.

## Acceptance criteria

- The builder supports `user_curated` mode.
- An `unreviewed-user-research.md` report is generated.
- `auditor_accepted_only` is optional, not the default.
