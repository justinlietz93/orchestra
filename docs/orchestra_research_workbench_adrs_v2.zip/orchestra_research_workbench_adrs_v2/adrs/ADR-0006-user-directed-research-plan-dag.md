# ADR-0006: Execute user-directed research plans as DAGs

**Status:** Proposed  
**Date:** 2026-07-13

## Decision

Represent complex research as a dependency-aware plan of questions and tasks.

The user may inspect, edit, pause, rerun, or cancel the plan.

Plan completion produces workbench artifacts only.

## Acceptance criteria

- Every task has explicit inputs and outputs.
- Failed tasks remain in the run record.
- No task targets a pipeline role.
