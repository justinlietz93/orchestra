# ADR-0004: Preserve immutable source snapshots

**Status:** Proposed  
**Date:** 2026-07-13

## Decision

Every internal or external source used by a run receives a SourceRecord and an immutable SourceSnapshot.

Record exact bytes when lawful and available. Otherwise preserve normalized content, metadata, retrieval time, locator, and hash.

## Acceptance criteria

- Every evidence item resolves to one snapshot.
- A later source version creates a new snapshot.
- An agent handoff can include a summary without falsely implying that source snapshots were also provided.
