# ADR Index

1. ADR-0001 — User-only Research Workbench sidecar
2. ADR-0002 — User-owned campaigns and immutable runs
3. ADR-0003 — Claim-centric user-research provenance
4. ADR-0004 — Immutable source snapshots
5. ADR-0005 — Provider-neutral connectors
6. ADR-0006 — User-directed research plan DAG
7. ADR-0007 — Attachment is not delivery
8. ADR-0008 — User-triggered councils
9. ADR-0009 — Content-addressed storage and indexing
10. ADR-0010 — Capability-by-capability Cogito migration
11. ADR-0011 — Separate workbench GUI branch
12. ADR-0012 — Per-run policies
13. ADR-0013 — Exposure ledger and handoff manifests
14. ADR-0014 — Publication provenance without false review claims

## Ratification order

Recommended first set:

- ADR-0001
- ADR-0007
- ADR-0011
- ADR-0013
- ADR-0014

These decisions establish the non-poisoning boundary before implementation begins.
