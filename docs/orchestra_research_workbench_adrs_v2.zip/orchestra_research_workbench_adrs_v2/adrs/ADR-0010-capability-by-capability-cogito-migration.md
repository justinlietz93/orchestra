# ADR-0010: Migrate Cogito capability by capability

**Status:** Proposed  
**Date:** 2026-07-13

## Decision

Do not merge the Cogito repository wholesale.

Port connectors, planners, critique templates, citation tools, and renderers behind workbench interfaces.

## Acceptance criteria

- Every migrated component has isolated tests.
- No migrated component imports pipeline workflow services.
- Each original Cogito component receives a reuse, adapt, rewrite, or reject disposition.
