# ADR-0002: Model user-owned campaigns and immutable research runs

**Status:** Proposed  
**Date:** 2026-07-13  
**Supersedes:** ADR-0002 from v1

## Decision

A ResearchCampaign is created and controlled by the user.

Every execution creates an immutable ResearchRun with fixed inputs, plan, source snapshots, outputs, errors, costs, and hashes.

A run is not an Operator interaction and has no pipeline authority.

## Acceptance criteria

- Rerunning creates a new run.
- Earlier run hashes remain unchanged.
- Run completion does not change workflow state.
- The GUI clearly labels the run as user research.
