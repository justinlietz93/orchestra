# ADR-0009: Store immutable content separately from project links

**Status:** Proposed  
**Date:** 2026-07-13

## Decision

Use SQLite for metadata and a content-addressed file store for immutable artifacts.

A p-b-v attachment may contain a summary snapshot and links to full workbench artifacts.

## Acceptance criteria

- Identical bytes share one content object.
- Attachment, exposure, and adoption remain separate metadata.
- Search indexing never alters exposure state.
