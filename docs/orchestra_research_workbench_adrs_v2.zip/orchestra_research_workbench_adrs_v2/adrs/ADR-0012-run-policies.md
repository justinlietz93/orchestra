# ADR-0012: Fix reproducibility, cost, privacy, and provider policies per run

**Status:** Proposed  
**Date:** 2026-07-13

## Decision

Every run freezes:

- budget policy;
- privacy policy;
- source-snapshot policy;
- provider and model versions;
- reproducibility level;
- cancellation policy.

## Acceptance criteria

- Policies are included in the run manifest.
- A rerun with changed policies creates a new run.
- Private source material is never sent to an external provider without an explicit run policy.
