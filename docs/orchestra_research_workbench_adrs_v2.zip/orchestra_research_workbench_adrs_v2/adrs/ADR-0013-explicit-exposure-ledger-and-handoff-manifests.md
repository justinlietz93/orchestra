# ADR-0013: Record exposure through an append-only ledger and exact handoff manifests

**Status:** Proposed  
**Date:** 2026-07-13

## Context

Project location does not prove agent exposure. Different agents may receive different subsets of a run.

## Decision

Record every user-authorized agent delivery as an immutable ExposureEvent and AgentHandoffManifest.

Each manifest is:

- role-specific;
- interaction-specific;
- artifact-specific;
- hash-specific.

## Rules

- No exposure is inferred from attachment.
- No exposure is inferred from search indexing.
- Providing a summary does not provide the full run.
- Providing to one role does not provide to another.
- A later correction creates a new manifest or event. It does not rewrite history.

## Acceptance criteria

- The GUI can answer exactly what each agent received.
- Generated handoff packages contain only manifest-listed artifacts.
- Manual external delivery can be recorded with `verification: user_reported`.
