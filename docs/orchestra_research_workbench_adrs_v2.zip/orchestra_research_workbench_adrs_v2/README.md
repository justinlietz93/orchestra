# Orchestra User Research Workbench

**Package version:** v2  
**Status:** Proposed architecture package  
**Purpose:** integrate Cogito Research capabilities as a user-only research sidecar without creating an implicit path into the Operator → Guardian → Auditor pipeline.

## Core decision

The Research Workbench is a separate user-controlled branch of the Orchestra desktop application.

It may:

- search internal project history;
- search external literature and selected web sources;
- run structured research plans;
- preserve source snapshots;
- compare claims and contradictions;
- run user-requested critique or synthesis councils;
- prepare notes, research summaries, and publication bundles;
- attach a user-generated summary to a selected phase-branch-version record.

It does not:

- send anything to the Operator, Guardian, or Auditor automatically;
- alter workflow position;
- alter phase, branch, or version;
- change project rules;
- imply that an attached artifact was provided to an agent;
- imply that a provided artifact was read, used, accepted, or adopted;
- promote a workbench claim into project canon.

## Provenance rule

These states are distinct:

```text
created
≠ attached to a p-b-v record
≠ provided to an agent
≠ acknowledged by an agent
≠ used by an agent
≠ audited
≠ adopted
≠ included in a paper
```

No later state may be inferred from an earlier one.

## Default safety behavior

- Workbench artifacts are excluded from agent handoff packages by default.
- Agent intake is defined only by an explicit handoff manifest.
- “Provided to X agent” is an explicit user action recorded as an immutable event.
- Search indexing never changes exposure state.
- The project graph displays origin, attachment, exposure, review, and adoption as separate badges.

## Package contents

- 14 ADRs
- architecture overview and domain model
- explicit exposure and handoff model
- publication provenance specification
- implementation roadmap
- JSON Schemas
- example records
- regression guardrails and validation report

## Replacement status

This package supersedes `orchestra_cogito_integration_adrs_v1`.

The v1 package incorrectly implied that completed workbench runs should normally enter the existing agent relay. Version 2 removes that coupling.
