# First Implementation Slice

## Goal

Prove that user research can be attached to project history without entering the agent pipeline.

## User story

1. The user selects a graph node.
2. The user creates an internal-only ResearchRun over selected project artifacts.
3. The run emits a hashed summary and provenance record.
4. The user attaches the summary to a selected p-b-v record.
5. Operator, Guardian, and Auditor exposure all remain `Not provided`.
6. Generated pipeline handoff packages exclude the attached summary.

## Minimum components

- `ResearchCampaignService`
- `ResearchRunService`
- `InternalCorpusConnector`
- `ArtifactSnapshotService`
- `ResearchSummaryService`
- `WorkbenchAttachmentService`
- `HandoffPackageExclusionPolicy`
- GUI Campaign, Run, and Attachment views

## Acceptance tests

- Workflow position is byte-for-byte unchanged.
- Attachment contains an origin warning.
- No ExposureEvent is created.
- Agent handoff package manifests omit the workbench artifact.
- Project search finds the summary with `USER RESEARCH`, `ATTACHED`, and `NOT PROVIDED` badges.
