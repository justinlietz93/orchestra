# Implementation Roadmap

## Phase 0 — Ratify isolation

Deliverables:

- ratified ADR-0001, ADR-0007, ADR-0011, ADR-0013, and ADR-0014;
- regression tests for all architecture invariants;
- exact current p-b-v folder and package-builder behavior documented.

Exit condition:

Attachment, agent delivery, review, adoption, and publication inclusion are represented as separate facts.

## Phase 1 — User research run foundation

Build:

- campaigns and immutable runs;
- content-addressed artifact store;
- manifests and hashes;
- run history;
- failure, retry, cancellation, and supersession.

Exit condition:

A local run completes without changing workflow state.

## Phase 2 — Internal research lane

Build:

- graph-node launch action;
- selected-artifact ingestion;
- claim and evidence extraction;
- status-aware result display;
- same-interaction context recovery.

Exit condition:

The user can investigate whether work already exists without granting it authority.

## Phase 3 — Summary attachment

Build:

- summary generator;
- `user-research/` attachment layout;
- provenance and artifact-link records;
- default handoff-package exclusion.

Exit condition:

A user summary can be attached to a selected p-b-v record while every agent remains `Not provided`.

## Phase 4 — Exposure ledger

Build:

- artifact selector;
- role-specific handoff manifest;
- immutable exposure events;
- manual-delivery recording;
- role and interaction filters.

Exit condition:

The application can prove exactly which bytes each agent received.

## Phase 5 — External connectors

Build and harden:

- ArXiv;
- CrossRef;
- Semantic Scholar;
- PubMed;
- selected web sources;
- source snapshots and deduplication.

Exit condition:

External research remains fully inside the user workbench until an explicit user action.

## Phase 6 — Structured user research agents

Build:

- editable research-plan DAG;
- critique and synthesis templates;
- structured evidence-linked outputs;
- dissent preservation;
- cost and privacy controls.

Exit condition:

Every generated claim links to evidence or is marked unsupported.

## Phase 7 — Publication builder

Build:

- manuscript claim selection;
- bibliography and citation map;
- claim-origin map;
- exposure ledger export;
- pipeline decision export when present;
- user-curated and auditor-accepted-only modes;
- provenance bundle and PDF rendering.

Exit condition:

A paper can be exported without overstating agent exposure or review.
